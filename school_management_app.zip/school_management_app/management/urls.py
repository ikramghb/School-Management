from django.urls import include, path
#from management.views import login
from . import views

urlpatterns = [
    path('',views.index,name='home'),
    path('login/',views.login_user,name='login'),
    #path('accounts/', include('django.contrib.auth.urls')),
    path('logout_user/', views.logout_user, name="logout_user"),
    
]
