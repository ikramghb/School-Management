
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver

from adminhod.models import AdminHOD
from staff.models import Staff
from student.models import Student
from teacher.models import Teacher
from .models import CustomUser

#Creating Django Signals

# It's like trigger in database. It will run only when Data is Added in CustomUser model

@receiver(post_save, sender=CustomUser)
# Now Creating a Function which will automatically insert data in HOD, Staff or Student
def create_user_profile(sender, instance, created, **kwargs):
    # if Created is true (Means Data Inserted)
    if created:
        # Check the user_type and insert the data in respective tables
        if instance.user_type == 1:
            AdminHOD.objects.create(admin=instance)
        if instance.user_type == 2:
            Staff.objects.create(admin=instance)
        if instance.user_type == 3:
            Teacher.objects.create(admin=instance)
        if instance.user_type == 4:
            Student.objects.create(admin=instance)
        
@receiver(post_save, sender=CustomUser)
def save_user_profile(sender, instance, **kwargs):
    if instance.user_type == 1:
        instance.adminhod.save()
    if instance.user_type == 2:
        instance.staff.save()
    if instance.user_type == 3:
        instance.teacher.save()
    if instance.user_type == 4:
        instance.student.save()



        

