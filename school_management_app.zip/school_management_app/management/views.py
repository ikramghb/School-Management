from django.shortcuts import render,redirect
from django.http import HttpResponse
from management.forms import login_forms
from management.EmailBackEnd import EmailBackEnd
from django.contrib.auth import authenticate, login, logout
from adminhod.models import AdminHOD
from student.models import Student
from staff.models import Staff
from teacher.models import Teacher
# Create your views here.
def index(request):
    admin = AdminHOD.objects.all().count()
    teacher = Teacher.objects.all().count()
    staff = Staff.objects.all().count()
    student = Student.objects.all().count()
    data = {'admin':admin,'teacher':teacher,'staff':staff,'student':student}
    return render(request,'management/index.html',data)
def login_user(request):
    form=login_forms
    if request.method=="POST":
        form=login_forms(request.POST)
        user = EmailBackEnd.authenticate(request, username=request.POST.get('username'), password=request.POST.get('password'))
        if user != None:
            login(request, user)
            user_type = user.user_type
            #return HttpResponse("Email: "+request.POST.get('email')+ " Password: "+request.POST.get('password'))
            if user_type == '1':
                return redirect('adminhod_home')
                
            elif user_type == '2':
                # return HttpResponse("Staff Login")
                return redirect('staff_home')
                
            elif user_type == '3':
                # return HttpResponse("Student Login")
                return redirect('teacher_home')
            elif user_type == '4':
                # return HttpResponse("Student Login")
                return redirect('student_home')
            else:
                
                return redirect('login')
        else:
            
            #return HttpResponseRedirect("/")
            return redirect('login')
        
    return render(request,'management/login.html',{'form':form})
    #return HttpResponse('login page')
    
def logout_user(request):
    logout(request)
    return redirect('login')
    #return HttpResponseRedirect('/')


