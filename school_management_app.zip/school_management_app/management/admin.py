from django import forms
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import Group
from .models import CustomUser
from adminhod.models import  AdminHOD
from staff.models import  Staff
from student.models import  Student
from teacher.models import  Teacher

# Register your models here.

class UserModel(UserAdmin):
     pass


admin.site.register(CustomUser, UserModel)
admin.site.unregister(Group)

