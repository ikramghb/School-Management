from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from django.db import models

# Create your models here.

# Overriding the Default Django Auth User and adding One More Field (user_type)
class CustomUser(AbstractUser):
    user_type_data = ((1, "HOD"), (2, "Staff"), (3, "Teacher"),(4, "Student"))
    user_type = models.CharField(default=1, choices=user_type_data, max_length=10)


    

    

    
