from django import forms
class login_forms(forms.Form):
    username = forms.CharField(label='User ID', max_length=25)
    password = forms.CharField(label='User Password',max_length=32,min_length=6, widget=forms.PasswordInput) 
