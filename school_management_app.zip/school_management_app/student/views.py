from django.shortcuts import render,redirect
from django.http import JsonResponse
from student.forms import student_profile_form
from student.models import Student,Student_leave
from adminhod.models import StudentResult,Student_attendance
from management.models import CustomUser
from django.core.paginator import Paginator
from datetime import datetime
from django.utils.dateparse import parse_date
from .forms import *
from .models import Student
# Create your views here.
def student_home(request):
    student_obj = Student.objects.get(admin=request.user.id)
    tottal_attendance=Student_attendance.objects.filter(student_id=student_obj).count()
    total_present=Student_attendance.objects.filter(student_id=student_obj,status='present').count()
    total_absent=Student_attendance.objects.filter(student_id=student_obj,status='absent').count()
    subject_name = []
    data_present = []
    data_absent = []
    attendance=Student_attendance.objects.filter(student_id=student_obj).order_by('-attendance_date')
    
    for att in attendance:
        if att.subject not in subject_name:
            subject_name.append(att.subject)
            
    for att in subject_name:
        present=Student_attendance.objects.filter(student_id=student_obj,status='present',subject=att).count()
        absent=Student_attendance.objects.filter(student_id=student_obj,status='absent',subject=att).count()
        data_present.append(present)
        data_absent.append(absent)
        
    
    content={
        'student':student_obj,
        "total_attendance": tottal_attendance,
        "attendance_present": total_present,
        "attendance_absent": total_absent,
        'subject':subject_name,
        'data_present':data_present,
        'data_absent':data_absent,
        }
    return render(request,'student/student_home.html',content)

def student_profile(request):
    student=Student.objects.get(admin=request.user.id)
    form=StudentForm
    if request.method=="GET":
        form=StudentForm(instance=student)
    else:
        form=StudentForm(request.POST,instance=student)
        if form.is_valid():
            form.save()
    
    content={'form':form}
    return render(request,'student/student_profile.html',content)
def upload_profile(request):
    student=Student.objects.get(admin=request.user.id)
    if request.method == 'POST':
        if len(request.FILES) != 0:
           profile_pic = request.FILES['profile_pic']
           student.profile_pic=profile_pic
           student.save()
           return redirect(student_profile)
    return render(request,'student/student_profile_change.html')

    student_profile_change
    


def student_result(request):
    student_id=Student.objects.get(admin=request.user.id)
    result=StudentResult.objects.filter(student_id=student_id)
    content={'result':result}
    return render(request,'student/student_result.html',content)

def student_leave(request):
    name=request.user.id
    student_id=Student.objects.get(admin=name)
    leave_data=Student_leave.objects.filter(name=student_id).order_by('-leave_date_start')
    content={'leave_data':leave_data}
    return render(request,'student/student_leave.html',content)

def student_leave_aply(request):
    name=request.user.id
    student_id=Student.objects.get(admin=name)
    leave_date_start=request.POST.get('leave_date_start')
    leave_date_end=request.POST.get('leave_date_end')
    leave_message=request.POST.get('leave_message')
    if leave_date_start and leave_date_end:
       delta=parse_date(leave_date_end)-parse_date(leave_date_start)
       total_leave=delta.days
    if request.method=="POST":
        form=Student_leave_form(request.POST)
        try:
            leave=Student_leave(name=student_id,leave_date_start=leave_date_start,leave_date_end=leave_date_end,leave_message=leave_message,leave_days=total_leave)
            leave.save()
            return redirect(student_leave)
        except:
            return redirect(student_leave)
    return render(request,'student/student_leave_aply.html')

def student_leave_cancel(request,id):
    leave_data=Student_leave.objects.get(pk=id)
    leave_data.delete()
    return redirect(student_leave)

def student_attendance(request):
    student_id=Student.objects.get(admin=request.user.id)
    attendance=Student_attendance.objects.filter(student_id=student_id).order_by('-attendance_date')
    paginator = Paginator(attendance, 30) # Show 10 student per page.
    page_number = request.GET.get('page')
    attendance = paginator.get_page(page_number)
    
    
    content={'attendance':attendance}
    return render(request,'student/student_attendance.html',content)

def student_class_schedule(request):
    return render(request,'student/student_class_schedule.html')
