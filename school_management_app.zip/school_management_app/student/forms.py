from django import forms
from django.forms import ModelForm
from management.models import CustomUser
from .models import *
class StudentSignUpForm(ModelForm):
      class Meta:
          model=CustomUser
          fields= ['username', 'password', 'first_name','last_name','email']

          
class StudentForm(ModelForm):
    class Meta:
        model=Student
        fields='__all__'
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['admin'].disabled = True
        


        
class student_profile_form(ModelForm):
     first_name = forms.CharField(max_length=30)
     last_name = forms.CharField(max_length=30)
     email = forms.EmailField(max_length=25)
     class Meta:
        model = CustomUser
        fields = [
            'username', 
            'first_name', 
            'last_name', 
            'email',
            ]
        
     def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].disabled = True
        self.fields['first_name'].disabled = True
        self.fields['last_name'].disabled = True
        self.fields['email'].disabled = True

class Student_leave_form(ModelForm):
    class Meta:
        model=Student_leave
        fields='__all__'
