from django.urls import  path
from . import views
from django.conf.urls.static import static
from django.conf import settings
urlpatterns =[
         path('',views.student_home,name='student_home'),
         path('student_profile/',views.student_profile,name='student_profile'),
         path('upload_profile',views.upload_profile,name='upload_profile'),
         path('student_result/',views.student_result,name='student_result'),
         path('student_leave/',views.student_leave,name='student_leave'),
         path('student_leave_aply/',views.student_leave_aply,name='student_leave_aply'),
         path('student_leave_cancel<int:id>',views.student_leave_cancel,name='student_leave_cancel'),
         path('student_attendance/',views.student_attendance,name='student_attendance'),
         path('student_class_schedule/',views.student_class_schedule,name='student_class_schedule'),
         
         ]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)       

