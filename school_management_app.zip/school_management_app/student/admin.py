from django.contrib import admin
from .models import Student,Student_leave
# Register your models here.
admin.site.register(Student)
admin.site.register(Student_leave)
