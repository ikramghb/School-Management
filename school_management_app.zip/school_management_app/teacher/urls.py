from django.urls import  path
#from teacher.views import teacher_home
from . import views
urlpatterns =[
         path('',views.teacher_home,name='teacher_home'),
         path('teacher_profile/',views.teacher_profile,name='teacher_profile'),
         path('teacher_upload_profile',views.teacher_upload_profile,name='teacher_upload_profile'),
         path('teacher_course/',views.teacher_course,name='teacher_course'),
         path('teacher_class_schedule/',views.teacher_class_schedule,name='teacher_class_schedule'),
         path('teacher_result/',views.teacher_result,name='teacher_result'),
         path('teacher_attendance/',views.teacher_attendance,name='teacher_attendance'),
         path('teacher_leave/',views.teacher_leave,name='teacher_leave'),
         path('teacher_leave_apply/',views.teacher_leave_apply,name='teacher_leave_apply'),
         path('teacher_leave_cancel/<int:id>',views.teacher_leave_cancel,name='teacher_leave_cancel'),
         ]        
