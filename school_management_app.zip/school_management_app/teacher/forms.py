from django.forms import ModelForm
from management.models import CustomUser
from django.forms.widgets import NumberInput
from .models import Teacher,Teacher_leave
class TeacherSignUpForm(ModelForm):
      class Meta:
          model=CustomUser
          fields= ['username', 'password', 'password']
class TeacherForm(ModelForm):
      class Meta:
            model=Teacher
            fields='__all__'

            widgets = {
                      'date_of_birth': NumberInput(attrs={'type': 'date'}),
                      
                  }
        
      def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['admin'].disabled = True
       



            
class Teacher_leave_form(ModelForm):
      
      class Meta:
              model=Teacher_leave
              fields='__all__'
              labels = {
                      'teacher_id': ('Teacher'),
                      'leave_date_start': ('Leave Start'),
                      'leave_date_end': ('Leave End'),
                      'leave_message': ('Leave Reason'),
                      'leave_status': ('Status'),
                      'leave_days': ('Total Leave'),
                  }
              widgets = {
                      'leave_date_start': NumberInput(attrs={'type': 'date'}),
                      'leave_date_end': NumberInput(attrs={'type': 'date'}),
                  }

