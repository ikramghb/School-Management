from django.contrib import admin
from .models import Teacher,Teacher_leave
# Register your models here.
admin.site.register(Teacher)
admin.site.register(Teacher_leave)
