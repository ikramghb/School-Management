from django.shortcuts import render,redirect
from .models import Teacher,Teacher_leave
from management.models import CustomUser
from adminhod.models import Subject,Teacher_attendance,StudentResult
from .forms import Teacher_leave_form,TeacherForm
from django.core.paginator import Paginator
from django.http import HttpResponse
from django.utils.dateparse import parse_date
import datetime

# Create your views here.
def teacher_home(request):
    teacher= Teacher.objects.get(admin=request.user.id)
    user = CustomUser.objects.get(pk=request.user.id)
    total_present=Teacher_attendance.objects.filter(teacher=teacher,status='present').count()
    total_absent=Teacher_attendance.objects.filter(teacher=teacher,status='absent').count()
    
    content={'total_present':total_present,'total_absent':total_absent}
    return render(request,'teacher/teacher_home.html',content)
def teacher_profile(request):
    teacher= Teacher.objects.get(admin=request.user.id)
    form=TeacherForm
    if request.method=="GET":
        form=TeacherForm(instance=teacher)
    else:
        form=TeacherForm(request.POST,instance=teacher)
        if form.is_valid():
            form.save()
    
    content={'form':form}
    return render(request,'teacher/teacher_profile.html',content)
def teacher_upload_profile(request):
    teacher=Teacher.objects.get(admin=request.user.id)
    if request.method == 'POST':
        if len(request.FILES) != 0:
           profile_pic = request.FILES['profile_pic']
           teacher.profile_pic=profile_pic
           teacher.save()
           return redirect(teacher_profile)
    return render(request,'teacher/teacher_profile_change.html')

def teacher_course(request):
    teacher= Teacher.objects.get(admin=request.user.id)
    course_data=Subject.objects.filter(teacher=teacher)
    content={'course_data':course_data}
    return render(request,'teacher/teacher_course.html',content)
def teacher_result(request):
    student=StudentResult.objects.all()
    content={'student':student}
    return render(request,'teacher/teacher_result.html',content)
def teacher_class_schedule(request):
    teacher= Teacher.objects.get(admin=request.user.id)
    user = CustomUser.objects.get(pk=request.user.id)
    content={'teacher':teacher,'user':user}    
    return render(request,'teacher/teacher_class_schedule.html',content)

def teacher_leave(request):
    teacher= Teacher.objects.get(admin=request.user.id)
    leave_data=Teacher_leave.objects.filter(teacher_id=teacher)
    content={'leave_data':leave_data}
    return render(request,'teacher/teacher_leave.html',content)

def teacher_leave_apply(request):
    form=Teacher_leave_form
    teacher= Teacher.objects.get(admin=request.user.id)
    if request.method=="POST":
        leave_date_start = request.POST.get('leave_date_start')
        leave_date_end = request.POST.get('leave_date_end')
        leave_message = request.POST.get('leave_message')
        if leave_date_start and leave_date_end:
             delta=parse_date(leave_date_end)-parse_date(leave_date_start)
             total_leave=delta.days
        try:
            leave=Teacher_leave(teacher_id=teacher,leave_date_start=leave_date_start,leave_date_end=leave_date_end,leave_message=leave_message,leave_days=total_leave)    
            leave.save()
            return redirect(teacher_leave)
        except:
            return redirect(teacher_leave_apply)
    content={'teacher':teacher,'form':form}   
    return render(request,'teacher/teacher_leave_apply.html',content)

def teacher_leave_cancel(request,id):
    leave=Teacher_leave.objects.get(pk=id)
    leave.delete()
    return redirect(teacher_leave)


def teacher_attendance(request):
    teacher= Teacher.objects.get(admin=request.user.id)
    attendance=Teacher_attendance.objects.filter(teacher=teacher).order_by('-attendance_date')
    paginator = Paginator(attendance, 20) # Show 20 student per page.
    page_number = request.GET.get('page')
    attendance = paginator.get_page(page_number)
    content={'attendance':attendance}
    return render(request,'teacher/teacher_attendance.html',content)
