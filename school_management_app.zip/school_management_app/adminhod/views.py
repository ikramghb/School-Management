from django.shortcuts import render,get_object_or_404
from django.shortcuts import redirect
from django.core.paginator import Paginator
from management.models import CustomUser
from student.models import Student,Student_leave
from teacher.models import Teacher,Teacher_leave
from staff.models import Staff,Staff_leave
from .models import AdminHOD,StudentResult,Session,Subject,Course,Class,Student_attendance,Teacher_attendance,Staff_attendance,Staff_duty
from student.forms import StudentSignUpForm
from adminhod.forms import SubjectForm,SignUpForm,StudentResultForm,ClassForm,Student_attendance_form,teacher_attendance_form,update_form,staff_duty, SessionForm,Admin_profile_form,CourseForm,Staff_attendance_form
from django.http import JsonResponse,HttpResponse
import datetime
#from .utils import get_plot
import csv
# Create your views here.
    
# Adminhod home profile 
def adminhod_home(request):
    # For Student
    st_attendance_date=[]
    subject_name = []
    subject_name_present = []
    subject_name_absent= []
    st_data_present = []
    st_data_absent = []
    st_attendance_present_list=Student_attendance.objects.filter(status='present').count()
    st_attendance_leave_list=Student_attendance.objects.filter(status='absent').count()
    
    student=Student_attendance.objects.all().order_by('-attendance_date')[:16]
    for st in student:
        
        if st.attendance_date not in st_attendance_date:
            st_attendance_date.append(st.attendance_date)
            
        if st.subject not in subject_name:
            subject_name.append(st.subject)
        
    
    for at in st_attendance_date:
        attent=Student_attendance.objects.filter(status='present',attendance_date=at).count()
        absent=Student_attendance.objects.filter(status='absent',attendance_date=at).count()
        st_data_present.append(attent)
        st_data_absent.append(absent)
        
    for subject in subject_name:
        present=Student_attendance.objects.filter(status='present',subject=subject).count()
        abs=Student_attendance.objects.filter(status='absent',subject=subject).count()
        subject_name_present.append(present)
        subject_name_absent.append(abs)


            
    
    #For Staff
    staff_attendance_date=[]
    staff_data_present = []
    staff_data_absent = []
    staff=Staff_attendance.objects.all().order_by('-attendance_date')[:16]
    for st in staff:
        if st.attendance_date not in staff_attendance_date:
            staff_attendance_date.append(st.attendance_date)
    
    for at in staff_attendance_date:
        attent=Staff_attendance.objects.filter(status='present',attendance_date=at).count()
        absent=Staff_attendance.objects.filter(status='absent',attendance_date=at).count()
        staff_data_present.append(attent)
        staff_data_absent.append(absent)
        
    staff_attendance_present_list=Staff_attendance.objects.filter(status='present').count()
    staff_attendance_leave_list=Staff_attendance.objects.filter(status='absent').count()
    


    #For Teacher
    teacher_attendance_date=[]
    teacher_data_present = []
    teacher_data_absent = []
    teacher_attendance_present_list=Teacher_attendance.objects.filter(status='present').count()
    teacher_attendance_leave_list=Teacher_attendance.objects.filter(status='absent').count()
    teacher=Teacher_attendance.objects.all().order_by('-attendance_date')[:16]
    for st in teacher:
        if st.attendance_date not in teacher_attendance_date:
            teacher_attendance_date.append(st.attendance_date)

    for at in teacher_attendance_date:
        att=Teacher_attendance.objects.filter(status='present',attendance_date=at).count()
        abs=Teacher_attendance.objects.filter(status='absent',attendance_date=at).count()
        teacher_data_present.append(att)
        teacher_data_absent.append(abs)
        

    
        
    
    content={
        'total_student':Student.objects.all().count(),
        'total_teacher':Teacher.objects.all().count(),
        'total_staff':Staff.objects.all().count(),
        'st_attendance_date':st_attendance_date,
        'subject':subject_name,
        'subject_name_present':subject_name_present,
        'subject_name_absent':subject_name_absent,
        'st_data_present':st_data_present,
        'st_data_absent':st_data_absent,
        'st_attendance_present_list':st_attendance_present_list,
        'st_attendance_leave_list':st_attendance_leave_list,
        'staff_attendance_date':staff_attendance_date,
        'staff_data_present':staff_data_present,
        'staff_data_absent':staff_data_absent,
        'staff_attendance_present_list':staff_attendance_present_list,
        'staff_attendance_leave_list':staff_attendance_leave_list,
        'teacher_attendance_date':teacher_attendance_date,
        'teacher_data_present':teacher_data_present,
        'teacher_data_absent':teacher_data_absent,
        'teacher_attendance_present_list':teacher_attendance_present_list,
        'teacher_attendance_leave_list':teacher_attendance_leave_list,
             }
    return render(request,'adminhod/adminhod_home.html',content)

def Admin_profile(request):
    user=CustomUser.objects.get(pk=request.user.id)
    if request.method=="GET":
        form=Admin_profile_form(instance=user)
    user = CustomUser.objects.get(pk=request.user.id)
    admin = AdminHOD.objects.get(admin=user)  
    content={'admin':admin,'user':user,'form':form}
    return render(request,'adminhod/adminhod_profile.html',content)

def Admin_update_profile(request):
    user=CustomUser.objects.get(pk=request.user.id)
    admin = AdminHOD.objects.get(admin=user) 
    if request.method=="GET":
        form=Admin_profile_form(instance=user)
    user = CustomUser.objects.get(pk=request.user.id)
     
    content={'admin':admin,'user':user,'form':form}
    return render(request,'adminhod/adminhod_profile.html')

def admin_upload_profile_change(request):
    user=CustomUser.objects.get(pk=request.user.id)
    admin = AdminHOD.objects.get(admin=user)
    if request.method == 'POST':
        if len(request.FILES) != 0:
           profile_pic = request.FILES['profile_pic']
           admin.profile_pic=profile_pic
           admin.save()
           return redirect(Admin_profile)
    return render(request,'adminhod/admin_profile_change.html')

# Session Manage
def magage_session(request):
    session=Session.objects.all()
    content={'session':session}
    return render(request,'adminhod/magage_session.html',content)

def session_add(request):
    form=SessionForm
    if request.method=="POST":
        #form=SessionForm(request.POST)
        name=request.POST.get('name')
        session_start=request.POST.get('session_start')
        session_end=request.POST.get('session_end')
        status=request.POST.get('status')
        try:
            data=Session(name=name,session_start=session_start,session_end=session_end,status=status)
            data.save()
            return redirect('magage_session')
        except:
            return redirect('magage_session')
    content={'form':form}
    return render(request,'adminhod/session_add.html',content)


def session_update(request,id):
    session_id=Session.objects.get(pk=id)
    if request.method=="GET":
        form=SessionForm(instance=session_id)
    else:
        #form=SessionForm(request.POST)
        name=request.POST.get('name')
        session_start=request.POST.get('session_start')
        session_end=request.POST.get('session_end')
        status=request.POST.get('status')
        try:
            session_id.name=name
            session_id.session_start=session_starte
            session_id.session_end=session_end
            session_id.status=status
            session_id.name=name
            session_id.save()
            return redirect('magage_session')
        except:
            return redirect('magage_session')
    content={'form':form}
    return render(request,'adminhod/session_update.html',content)

def session_delete(request,id):
    session_id=Session.objects.get(pk=id)
    session_id.delete()
    return redirect('magage_session')
    
def academic_class(request):
    cl=Class.objects.all()
    content={'class':cl}
    return render(request,'adminhod/academic_class.html',content)

def academic_class_add(request):
    form=ClassForm
    if request.method=="POST":
        form=ClassForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('academic_class')
    content={'form':form}
    return render(request,'adminhod/academic_class_add.html',content)
    
def academic_class_update(request,id):
    class_id=Class.objects.get(pk=id)
    if request.method=="GET":
        form=ClassForm(instance=class_id)
    else:
        form=ClassForm(request.POST,instance=class_id)
        if form.is_valid():
            form.save()
            return redirect('academic_class')
    content={'form':form}
    return render(request,'adminhod/academic_class_update.html',content)

def academic_class_delete(request,id):
    class_id=Class.objects.get(pk=id)
    class_id.delete()
    return redirect('academic_class')

# Course Manage
def magage_course(request):
    course=Course.objects.all()
    content={'course':course}
    return render(request,'adminhod/magage_course.html',content)
def course_add(request):
    form=CourseForm
    if request.method=="POST":
        form=CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('magage_course')
    content={'form':form}
    return render(request,'adminhod/course_add.html',content)

def course_update(request,id):
    course=Course.objects.get(pk=id)
    if request.method=="GET":
        form=CourseForm(instance=course)
    else:
        form=CourseForm(request.POST,instance=course)
        if form.is_valid():
            form.save()
            return redirect('magage_course')
    content={'form':form}
    return render(request,'adminhod/course_update.html',content)
    
def course_delete(request,id):
    course_id=Course.objects.get(pk=id)
    course_id.delete()
    return redirect('magage_course')


# Subject Manage
def magage_subject(request):
    subject=Subject.objects.all()
    form=SubjectForm
    if request.method=="POST":
        form=SubjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('magage_subject')
    content={'form':form,'subject':subject}
    return render(request,'adminhod/magage_subject.html',content)


def subject_add(request):
    form=SubjectForm
    if request.method=="POST":
        form=SubjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('magage_subject')
    content={'form':form}
    return render(request,'adminhod/subject_add.html',content)


def subject_update(request,id):
    subject=Subject.objects.get(pk=id)
    
    if request.method=="GET":
        form=SubjectForm(instance=subject)
    else:
        form=SubjectForm(request.POST,instance=subject)
        if form.is_valid():
            form.save()
            return redirect('magage_subject')
    content={'form':form}
    return render(request,'adminhod/subject_update.html',content)


def subject_delete(request,id):
    subject_id=Subject.objects.get(pk=id)
    subject_id.delete()
    return redirect('magage_subject')
    




#Student
def admin_student_result(request):
    student=StudentResult.objects.all()

    content={'student':student}
    return render(request,'adminhod/admin_student_result.html',content)
def admin_student_result_add(request):
    form=StudentResultForm
    if request.method=="POST":
        form=StudentResultForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admin_student_result')
    content={'form':form}
    return render(request,'adminhod/admin_student_result_add.html',content)

def admin_student_result_edit(request,id):
    result=StudentResult.objects.get(pk=id)
    if request.method=="POST":
        form=StudentResultForm(request.POST,instance=result)
        if form.is_valid():
            form.save()
            return redirect('admin_student_result')
    else:
        form=StudentResultForm(instance=result)
    content={'form':form}
    return render(request,'adminhod/admin_student_result_add.html',content)


def admin_student_attendance(request):
    attendance=Student_attendance.objects.all().order_by('-attendance_date')
    paginator = Paginator(attendance, 20) # Show 10 student per page.
    page_number = request.GET.get('page')
    attendance = paginator.get_page(page_number)
    content={'attendance':attendance}
    return render(request,'adminhod/admin_student_attendance.html',content)
    
def admin_student_attendance_add(request):
    form=Student_attendance_form
    if request.method=="POST":
        form=Student_attendance_form(request.POST)
        if form.is_valid():
            form.save()
            return redirect(admin_student_attendance)
    content={'form':form}
    return render(request,'adminhod/admin_student_attendance_add.html',content)

def admin_student_attendance_add_csv(request):
    return render(request,'adminhod/admin_student_attendance_add_csv.html')

def admin_student_attendance_edit(request,id):
    attendance=Student_attendance.objects.get(pk=id)
    if request.method=="POST":
        form=Student_attendance_form(request.POST,instance=attendance)
        if form.is_valid():
            form.save()
            return redirect(admin_student_attendance)
    else:
        form=Student_attendance_form(instance=attendance)
    content={'form':form}
    return render(request,'adminhod/admin_student_attendance_add.html',content)


    
def admin_student_management(request):
    st_total=CustomUser.objects.filter(user_type=4).count()
    student=CustomUser.objects.filter(user_type=4)   
    paginator = Paginator(student, 10) # Show 10 student per page.
    page_number = request.GET.get('page')
    student = paginator.get_page(page_number)
    #student=Student.objects.all()
    content={'student':student,'st_total':st_total}
    #return JsonResponse(content)
    return render(request,'adminhod/admin_student_management.html',content)

def student_managemet_search(request):
    starts_with=request.GET.get('st_search')
    student_list = CustomUser.objects.filter(admin__istartswith=starts_with ,email__istartswith=starts_with )
    result={'result':student_list}
    return JsonResponse(result)

    
def admin_student_leave(request):

    
    st_leave=Student_leave.objects.all()
    paginator = Paginator(st_leave, 20) # Show 10 student per page.
    page_number = request.GET.get('page')
    st_leave = paginator.get_page(page_number)
    content={'st_leave':st_leave}
    return render(request,'adminhod/admin_student_leave.html',content)

def student_leave_approve(request,id):
    data = get_object_or_404(Student_leave,pk= id) 
    data.leave_status=1
    data.save()  
    return redirect('admin_student_leave')


def student_leave_reject(request, id):
    data = get_object_or_404(Student_leave,pk= id) 
    data.leave_status=2
    data.save()  
    return redirect('admin_student_leave')
   



def StudentSignUpView(request):
    model=CustomUser
    form = StudentSignUpForm
    if request.method=="POST":
        form=StudentSignUpForm(request.POST)
        if form.is_valid():
             username=request.POST.get('username')
             first_name=request.POST.get('first_name')
             last_name=request.POST.get('last_name')
             email=request.POST.get('email')
             password=request.POST.get('password')
             user = CustomUser.objects.create_user(username=username,password=password,first_name=first_name,last_name=last_name,email=email,user_type=4)
             user.save()
             return redirect('student_signup')
            
            
    return render(request,'registration/student_signup_form.html',{'form':form})


def update_student(request,id):
    st=CustomUser.objects.get(username=id)
    form=update_form()
    if request.method=="GET":
        form=update_form(instance=st)
    else:
        form=update_form(request.POST,instance=st)
        if form.is_valid():
            form.save()
            return redirect(admin_student_management)
    content={'form':form,'st':st}
    return render(request,'adminhod/admin_update_student.html',content)

def delete_student(request):
    user = request.GET.get('username')
    st_id=CustomUser.objects.get(username=user)
    st_id.delete()
    data = {'deleted': True}
    return JsonResponse(data)
def student_data_csv(request):
    student=CustomUser.objects.filter(user_type=4)
    response=HttpResponse(content_type='text/csv')
    response['content-Disposition']='attachment; filename=student_data-'+str(datetime.datetime.now())+'.csv'
    writer=csv.writer(response)
    writer.writerow(['username','First Name','Last Name','Email'])
    for st in student:
        writer.writerow([st.username,st.first_name,st.last_name,st.email])
    return response

def student_data_pdf(request):
    student=CustomUser.objects.filter(user_type=4)
    #people = Person.objects.all().order_by('last_name')

    response=HttpResponse(content_type='text/pdf')
    return response



    
#Teacher
def admin_teacher_course(request):
    return render(request,'adminhod/admin_teacher_course.html')

def admin_teacher_attendance(request):
    attendance=Teacher_attendance.objects.all().order_by('-attendance_date')
    paginator = Paginator(attendance, 20) # Show 10 student per page.
    page_number = request.GET.get('page')
    attendance = paginator.get_page(page_number)
    content={'attendance':attendance}
    return render(request,'adminhod/admin_teacher_attendance.html',content)

def admin_teacher_attendance_add(request):
    form=teacher_attendance_form
    if request.method=="POST":
        form=teacher_attendance_form(request.POST)
        if form.is_valid():
            form.save()
    content={'form':form}
    return render(request,'adminhod/admin_teacher_attendance_add.html',content)

def admin_teacher_management(request):
    #teacher=Teacher.objects.all()
    teacher=CustomUser.objects.filter(user_type=3)
    paginator = Paginator(teacher, 20) # Show 10 student per page.
    page_number = request.GET.get('page')
    teacher = paginator.get_page(page_number)
    content={'teacher':teacher}
    return render(request,'adminhod/admin_teacher_management.html',content)

def admin_teacher_leave(request):
    teacher_leave=Teacher_leave.objects.all()
    content={'teacher_leave':teacher_leave}
    return render(request,'adminhod/admin_teacher_leave.html',content)



def teacher_leave_approve(request,id):
    leave = Teacher_leave.objects.get(pk=id)
    leave.leave_status = 1
    leave.save()
    return redirect('admin_teacher_leave')

def teacher_leave_reject(request,id):
    leave = Teacher_leave.objects.get(pk=id)
    leave.leave_status = 2
    leave.save()
    return redirect('admin_teacher_leave')



def TeacherSignUpView(request):
    model=CustomUser
    form = StudentSignUpForm
    if request.method=="POST":
        form=StudentSignUpForm(request.POST)
        if form.is_valid():
             username=request.POST.get('username')
             first_name=request.POST.get('first_name')
             last_name=request.POST.get('last_name')
             email=request.POST.get('email')
             password=request.POST.get('password')
             user = CustomUser.objects.create_user(username=username,password=password,first_name=first_name,last_name=last_name,email=email,user_type=3)
             user.save()
             return redirect('teacher_signup')
            
    return render(request,'registration/teacher_signup_form.html',{'form':form})


def update_teacher(request,id):
    teacher=CustomUser.objects.get(username=id)
    form=update_form()
    if request.method=="GET":
        form=update_form(instance=teacher)
    else:
        form=update_form(request.POST,instance=teacher)
        if form.is_valid():
            form.save()
            return redirect(admin_teacher_management)
    content={'form':form}
    return render(request,'adminhod/admin_update_teacher.html',content)

def delete_teacher(request,id):
    teacher_id=CustomUser.objects.get(username=id)
    teacher_id.delete()
    return redirect(admin_teacher_management)

def teacher_data_csv(request):
    teacher=CustomUser.objects.filter(user_type=3)
    response=HttpResponse(content_type='text/csv')
    response['content-Disposition']='attachment; filename=teacher_data-'+str(datetime.datetime.now())+'.csv'
    writer=csv.writer(response)
    writer.writerow(['username','First Name','Last Name','Email'])
    for st in teacher:
        writer.writerow([st.username,st.first_name,st.last_name,st.email])
    return response


  
#Staff Manage


def admin_staff_duety(request):
    duty=Staff_duty.objects.all()
    content={'duty':duty}
    return render(request,'adminhod/admin_staff_duety.html',content)

def admin_staff_duety_add(request):
    form=staff_duty
    if request.method=="POST":
        form=staff_duty(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admin_staff_duety')

    content={'form':form}
    return render(request,'adminhod/admin_staff_duety_add.html',content)
def admin_staff_duety_edit(request,id):
    duty=Staff_duty.objects.get(pk=id)
    #form=staff_duty
    if request.method=="POST":
        form=staff_duty(request.POST,instance=duty)
        if form.is_valid():
            form.save()
            return redirect('admin_staff_duety')
    else:
        form=staff_duty(instance=duty)
    content={'form':form}
    return render(request,'adminhod/admin_staff_duety_add.html',content)

def admin_staff_duety_cancel(request,id):
    duty=Staff_duty.objects.get(pk=id)
    duty.delete()
    return redirect('admin_staff_duety')

def admin_staff_attendance(request):
    attendance=Staff_attendance.objects.all().order_by('-attendance_date')
    paginator = Paginator(attendance, 20) # Show 10 student per page.
    page_number = request.GET.get('page')
    attendance = paginator.get_page(page_number)
    content={'attendance':attendance}
    return render(request,'adminhod/admin_staff_attendance.html',content)


def admin_staff_attendance_add(request):
    form=Staff_attendance_form
    if request.method=="POST":
        form=Staff_attendance_form(request.POST)
        if form.is_valid():
            form.save()
            return redirect(admin_staff_attendance)
    content={'form':form}
    return render(request,'adminhod/admin_staff_attendance_add.html',content)

def admin_staff_attendance_add_csv(request):
    return render(request,'adminhod/admin_staff_attendance_add_csv.html')

    
def admin_staff_management(request):
    #staff=Staff.objects.all()
    staff=CustomUser.objects.filter(user_type=2)
    paginator = Paginator(staff, 20) # Show 10 student per page.
    page_number = request.GET.get('page')
    staff = paginator.get_page(page_number)
    content={'staff':staff}
    return render(request,'adminhod/admin_staff_management.html',content)

def admin_staff_leave(request):
    staff=Staff_leave.objects.all()
    paginator = Paginator(staff, 20) # Show 10 student per page.
    page_number = request.GET.get('page')
    staff = paginator.get_page(page_number)
    content={'staff_leave':staff}
    return render(request,'adminhod/admin_staff_leave.html',content)


def staff_leave_approve(request,id):
    leave = Staff_leave.objects.get(pk=id)
    leave.leave_status = 1
    leave.save()
    return redirect('admin_staff_leave')

def staff_leave_reject(request,id):
    leave = Staff_leave.objects.get(pk=id)
    leave.leave_status = 2
    leave.save()
    return redirect('admin_staff_leave')


def StaffSignUpView(request):
    model=CustomUser
    form = StudentSignUpForm
    if request.method=="POST":
        form=StudentSignUpForm(request.POST)
        if form.is_valid():
             username=request.POST.get('username')
             first_name=request.POST.get('first_name')
             last_name=request.POST.get('last_name')
             email=request.POST.get('email')
             password=request.POST.get('password')
             try:
                user = CustomUser.objects.create_user(username=username,password=password,first_name=first_name,last_name=last_name,email=email,user_type=2)
                user.save()
                return redirect('staff_signup')
             except:
                return redirect('staff_signup')
                
            
    return render(request,'registration/staff_signup_form.html',{'form':form})
  
def update_staff(request,id):
    staff=CustomUser.objects.get(username=id)
    form=update_form()
    if request.method=="GET":
        form=update_form(instance=staff)
    else:
        form=update_form(request.POST,instance=staff)
        if form.is_valid():
            form.save()
            return redirect(admin_staff_management)
    content={'form':form}
    return render(request,'adminhod/admin_update_staff.html',content)

def delete_staff(request,id):
    st_id=CustomUser.objects.get(username=id)
    st_id.delete()
    return redirect('admin_staff_management')




