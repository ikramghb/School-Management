from django.contrib import admin
from adminhod.models import *
# Register your models here.
admin.site.register(AdminHOD)
admin.site.register(Session)
admin.site.register(Course)
admin.site.register(Subject)
admin.site.register(Class)
admin.site.register(Staff_duty)
admin.site.register(StudentResult)
admin.site.register(Student_attendance)
admin.site.register(Teacher_attendance)
admin.site.register(Staff_attendance)
admin.site.register(NotificationStudent)
admin.site.register(NotificationStaff)
admin.site.register(NotificationTeacher)
