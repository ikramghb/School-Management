from django.db import models
from django.utils import timezone
from management.models import CustomUser
from student.models import Student
from teacher.models import Teacher
from staff.models import Staff
# Create your models here.
class AdminHOD(models.Model):
    id = models.AutoField(primary_key=True)
    admin = models.OneToOneField(CustomUser, on_delete = models.CASCADE)
    first_name=models.CharField(max_length=100,blank=True,null=True)
    last_name=models.CharField(max_length=100,blank=True,null=True)
    email=models.EmailField(max_length=100,blank=True,null=True)
    profile_pic=models.ImageField(default='default.jpg',upload_to='profile',blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()

class Session(models.Model):
    id = models.AutoField(primary_key=True)
    name=models.CharField(max_length=100,unique=True,blank=False)
    status_type = (('active', 'Active'), ('inactive', 'Inactive'))
    status= models.CharField(default='inactive', choices=status_type, max_length=10,blank=True)
    session_start = models.DateField()
    session_end = models.DateField()
    objects = models.Manager()
    def __str__(self):
        return f'{self.name}'
    
class Course(models.Model):
    id = models.AutoField(primary_key=True)
    course_name = models.CharField(max_length=100,unique=True,blank=False)
    status_type = (('active', "Active"), ('inactive', "Inactive"))
    status= models.CharField(default='inactive', choices=status_type, max_length=10)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()
    
    def __str__(self):
        return f'{self.course_name}'
    
class Class(models.Model):
        id = models.AutoField(primary_key=True)
        name=models.CharField(max_length=100,unique=True,blank=False)
        status_type = (('active', "Active"), ('inactive', "Inactive"))
        status= models.CharField(default='inactive', choices=status_type, max_length=10)
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        objects = models.Manager()
        def __str__(self):
             return f'{self.name}'

class Subject(models.Model):
    id = models.AutoField(primary_key=True)
    subject_name = models.CharField(max_length=255)
    course_id = models.ForeignKey(Course, on_delete=models.CASCADE)
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()
    def __str__(self):
        return f'{self.subject_name}'

class StudentResult(models.Model):
    id = models.AutoField(primary_key=True)
    student_id = models.ForeignKey(Student, on_delete=models.CASCADE)
    subject_id = models.ForeignKey(Subject, on_delete=models.CASCADE)
    class_name=models.ForeignKey(Class, on_delete=models.CASCADE)
    course=models.ForeignKey(Course, on_delete=models.CASCADE)
    subject_exam_marks = models.FloatField(default=0)
    subject_assignment_marks = models.FloatField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()
    
    def __str__(self):
        return f'{self.student_id}'
    

class Student_attendance(models.Model):
    id = models.AutoField(primary_key=True)
    student_id= models.ForeignKey(Student, on_delete=models.DO_NOTHING)
    subject= models.ForeignKey(Subject, on_delete=models.DO_NOTHING)
    attendance_date = models.DateField()
    session= models.ForeignKey(Session, on_delete=models.CASCADE)
    status_type = (('present', "Present"), ('absent', "Absent"))
    status= models.CharField(default='absent', choices=status_type, max_length=10)
    objects = models.Manager()

class Teacher_attendance(models.Model):
    id = models.AutoField(primary_key=True)
    teacher= models.ForeignKey(Teacher, on_delete=models.DO_NOTHING)
    attendance_date = models.DateField()
    session= models.ForeignKey(Session, on_delete=models.CASCADE)
    status_type = (('present', "Present"), ('absent', "Absent"))
    status= models.CharField(default='absent', choices=status_type, max_length=10)
    objects = models.Manager()

class Staff_attendance(models.Model):
    id = models.AutoField(primary_key=True)
    staff= models.ForeignKey(Staff, on_delete=models.DO_NOTHING)
    attendance_date = models.DateField()
    session= models.ForeignKey(Session, on_delete=models.CASCADE)
    status_type = (('present', "Present"), ('absent', "Absent"))
    status= models.CharField(default='absent', choices=status_type, max_length=10)
    objects = models.Manager()
    
class Staff_duty(models.Model):
    id = models.AutoField(primary_key=True)
    staff= models.ForeignKey(Staff, on_delete=models.DO_NOTHING)
    date = models.DateField()
    start_duty = models.DateTimeField()
    end_duty = models.DateTimeField()
    objects = models.Manager()
    
    
class ClassRoutin(models.Model):
    pass

    
class NotificationStudent(models.Model):
    id = models.AutoField(primary_key=True)
   
    student_id = models.ForeignKey(Student, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()


class NotificationStaff(models.Model):
    id = models.AutoField(primary_key=True)
    #published=models.DateField()
    stafff_id = models.ForeignKey(Staff, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()

class NotificationTeacher(models.Model):
    id = models.AutoField(primary_key=True)
    #published=models.DateField()
    teacher_id = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()

