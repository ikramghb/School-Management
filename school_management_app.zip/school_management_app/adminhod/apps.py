from django.apps import AppConfig


class AdminhodConfig(AppConfig):
    name = 'adminhod'
