from django import forms
from django.forms import ModelForm
from django.contrib.auth.models import User
from django.forms.widgets import NumberInput
from django.contrib.admin import widgets
from django.contrib.auth.forms import UserCreationForm
from management.models import CustomUser
from .models import Session,Course,Subject,StudentResult,Class,Student_attendance,Teacher_attendance,Staff_attendance,Staff_duty

class Admin_profile_form(ModelForm):
     first_name = forms.CharField(max_length=30)
     last_name = forms.CharField(max_length=30)
     email = forms.EmailField(max_length=25)
     class Meta:
        model = CustomUser
        fields = [
            'username', 
            'first_name', 
            'last_name', 
            'email',
            ]
        
     def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].disabled = True
        self.fields['first_name'].disabled = True
        self.fields['last_name'].disabled = True
        self.fields['email'].disabled = True

      

       
class StudentSignUpForm(ModelForm):
      password=forms.CharField(widget=forms.PasswordInput())
      class Meta:
          model=CustomUser
          fields = [
            'username', 
            'first_name', 
            'last_name', 
            'email', 
            'password',
            'is_active',
            'is_staff',
            ]
          
class SessionForm(ModelForm):
     class Meta:
          model=Session
          fields='__all__'
          widgets = {
                      'session_start': NumberInput(attrs={'type': 'date'}),
                      'session_end': NumberInput(attrs={'type': 'date'}),
                  }

class CourseForm(ModelForm):
      class Meta:
          model=Course
          fields='__all__'
class ClassForm(ModelForm):
      class Meta:
          model=Class
          fields='__all__'
class SubjectForm(ModelForm):
      class Meta:
          model=Subject
          fields='__all__'

class StudentResultForm(ModelForm):
      class Meta:
          model=StudentResult
          fields='__all__'

class Student_attendance_form(ModelForm):
     class Meta:
           model=Student_attendance
           fields='__all__'
           widgets = {
                      'attendance_date': NumberInput(attrs={'type': 'date'}),
                  }

class teacher_attendance_form(ModelForm):
     class Meta:
           model=Teacher_attendance
           fields='__all__'
           widgets = {
                      'attendance_date': NumberInput(attrs={'type': 'date'}),
                  }

class Staff_attendance_form(ModelForm):
     class Meta:
           model=Staff_attendance
           fields='__all__'
           widgets = {
                      'attendance_date': NumberInput(attrs={'type': 'date'}),
                      }

class update_form(ModelForm):
     username = forms.CharField(max_length=30,disabled=True, required=True, help_text='Your Username')
     password=forms.CharField(widget=forms.PasswordInput(),disabled=True)
     first_name = forms.CharField(max_length=30, required=True, help_text='Your First Name')
     last_name = forms.CharField(max_length=30, required=True, help_text='Your Last Name')
     email = forms.EmailField(max_length=254, help_text='Enter a valid email address')
     class Meta:
        model = CustomUser
        fields = [
            'username', 
            'password', 
            'last_name',
            'first_name',
            'email',
            ]
            
        

class staff_duty(ModelForm):
     start_duty = forms.SplitDateTimeField(widget=widgets.AdminSplitDateTime)
     end_duty = forms.SplitDateTimeField(widget=widgets.AdminSplitDateTime)
     class Meta:
        model=Staff_duty
        fields='__all__'
        widgets = {
                      'date': NumberInput(attrs={'type': 'date'}),
                  }

     
          
          
class SignUpForm(UserCreationForm):

     first_name = forms.CharField(max_length=30, required=True, help_text='Your First Name')
     last_name = forms.CharField(max_length=30, required=True, help_text='Your Last Name')
     username = forms.CharField(max_length=30, required=True, help_text='Your Username')
     email = forms.EmailField(max_length=254, help_text='Enter a valid email address')
     password=forms.CharField(widget=forms.PasswordInput())
     confirm_password=forms.CharField(widget=forms.PasswordInput()) 

     class Meta:
        model = CustomUser
        fields = [
            'username', 
            'first_name', 
            'last_name', 
            'email', 
            'password',
            'confirm_password',
            'is_active',
            'is_staff',
            ]
     def clean(self):
        cleaned_data = super(SignUpForm, self).clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password != confirm_password:
            raise forms.ValidationError(
                "password and confirm_password does not match"
            )

