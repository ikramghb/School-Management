from django.forms import ModelForm
from management.models import CustomUser
from django.forms.widgets import NumberInput
from .models import Staff,Staff_leave
class StaffSignUpForm(ModelForm):
      class Meta:
          model=CustomUser
          fields= ['username', 'password', 'password']

class StaffForm(ModelForm):
      class Meta:
            model=Staff
            fields='__all__'
            widgets = {
                      'date_of_birth': NumberInput(attrs={'type': 'date'}),
                      
                  }
      def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['admin'].disabled = True


class Staff_leave_form(ModelForm):
    class Meta:
        model=Staff_leave
        fields='__all__'
        widgets = {
                      'leave_date_start': NumberInput(attrs={'type': 'date'}),
                      'leave_date_end': NumberInput(attrs={'type': 'date'}),
                  }
        labels = {
            'staff_id': ('Staff'),
            'leave_date_start': ('Leave Start'),
            'leave_date_end': ('Leave End'),
            'leave_message': ('Leave Reason'),
            'leave_status': ('Status'),
            'leave_days': ('Total Leave'),
                  }


