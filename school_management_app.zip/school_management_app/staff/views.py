from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.core.paginator import Paginator
from staff.models import Staff,Staff_leave
from management.models import CustomUser
from adminhod.models import Staff_attendance,Staff_duty
from .forms import Staff_leave_form,StaffForm
# Create your views here.

def staff_home(request):
    user=CustomUser.objects.get(pk=request.user.id)
    staff=Staff.objects.get(admin=user)
    present=Staff_attendance.objects.filter(status='present',staff=staff).count()
    absent=Staff_attendance.objects.filter(status='absent',staff=staff).count()

    duty=Staff_duty.objects.filter(staff=staff)
    content={'present':present,'absent':absent,'duty':duty}
    return render(request,'staff/staff_home.html',content)

def staff_profile(request):
    user=CustomUser.objects.get(pk=request.user.id)
    staff=Staff.objects.get(admin=user)
    form=StaffForm
    if request.method=="GET":
        form=StaffForm(instance=staff)
    else:
        form=StaffForm(request.POST,instance=staff)
        if form.is_valid():
            form.save()
    
    content={'form':form}
    return render(request,'staff/staff_profile.html',content)
def staff_update_profile(request):
    return render(request,'staff/staff_home.html')

def staff_upload_profile(request):
    staff=Staff.objects.get(admin=request.user.id)
    if request.method == 'POST':
        if len(request.FILES) != 0:
           profile_pic = request.FILES['profile_pic']
           staff.profile_pic=profile_pic
           staff.save()
           return redirect(staff_profile)
    return render(request,'staff/staff_profile_change.html')


def staff_change_password():
    return render(request,'staff/staff_home.html')

def staff_duety(request):
    user=CustomUser.objects.get(pk=request.user.id)
    staff=Staff.objects.get(admin=user)
    duty=Staff_duty.objects.filter(staff=staff)
    content={'duty':duty}
    return render(request,'staff/staff_duety.html',content)
    #return render(request,'staff/staff_duety.html')

def staff_leave(request):
    staff=Staff.objects.get(admin=request.user.id)
    leave_data=Staff_leave.objects.filter(staff_id=staff)
    content={'leave_data':leave_data}
    return render(request,'staff/staff_leave.html',content)

def staff_leave_aply(request):
    user=CustomUser.objects.get(pk=request.user.id)
    staff=Staff.objects.get(admin=user)
    form=Staff_leave_form
    if request.method=="POST":
        leave_date_start=request.POST.get('leave_date_start')
        leave_date_end=request.POST.get('leave_date_end')
        leave_message=request.POST.get('leave_message')
        try:
            leave=Staff_leave(staff_id=staff,leave_date_start=leave_date_start,leave_date_end=leave_date_end,leave_message=leave_message)
            leave.save()
            return redirect(staff_leave)
        except:
            return redirect(staff_leave)
    content={'form':form,'user':user,'staff':staff}
    return render(request,'staff/staff_leave_aply.html',content)

def staff_leave_cancel(request,id):
    leave=Staff_leave.objects.get(pk=id)
    leave.delete()
    return redirect(staff_leave)

def staff_attendance(request):
    staff=Staff.objects.get(admin=request.user.id)
    attendance=Staff_attendance.objects.filter(staff=staff).order_by('-attendance_date')
    paginator = Paginator(attendance, 20) # Show 10 student per page.
    page_number = request.GET.get('page')
    attendance = paginator.get_page(page_number)
    content={'attendance':attendance}
    return render(request,'staff/staff_attendance.html',content)



