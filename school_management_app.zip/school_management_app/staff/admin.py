from django.contrib import admin
from .models import Staff,Staff_leave
# Register your models here.
admin.site.register(Staff)
admin.site.register(Staff_leave)
