from django.urls import path
#from staff.views import staff_home
from . import views
urlpatterns =[
         path('',views.staff_home,name='staff_home'),
         path('staff_profile/',views.staff_profile,name='staff_profile'),
         path('staff_upload_profile/',views.staff_upload_profile,name='staff_upload_profile'),
         path('staff_duety/',views.staff_duety,name='staff_duety'),
         path('staff_leave/',views.staff_leave,name='staff_leave'),
         path('staff_leave_aply',views.staff_leave_aply,name='staff_leave_aply'),
         path('staff_leave_cancel/<int:id>',views.staff_leave_cancel,name='staff_leave_cancel'),
         path('staff_attendance/',views.staff_attendance,name='staff_attendance'),
         
         ]        
