from django.db import models
from django.utils import timezone
from management.models import CustomUser

# Create your models here.
class Staff(models.Model):
    GENDER = [
      ('Male', 'Male'),
      ('Female', 'Female')
     ]
    id = models.AutoField(primary_key=True)
    admin = models.OneToOneField(CustomUser, on_delete = models.CASCADE)
    first_name=models.CharField(max_length=100,blank=True,null=True)
    last_name=models.CharField(max_length=100,blank=True,null=True)
    email=models.EmailField(max_length=100,blank=True,null=True)
    profile_pic=models.ImageField(default='default.jpg',upload_to='profile',blank=True)
    father_name = models.CharField(max_length=200)
    mother_name = models.CharField(max_length=200)
    gende = models.CharField(max_length=10, choices=GENDER, default='male')
    date_of_birth= models.DateField(default=timezone.now)
    address = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()
    
    def __str__(self):
        return f'{self.admin.username}'
    

class Staff_leave(models.Model):
    id = models.AutoField(primary_key=True)
    staff_id = models.ForeignKey(Staff,on_delete = models.CASCADE)
    leave_date_start =models.DateField(default=timezone.now)
    leave_date_end =models.DateField(default=timezone.now)
    leave_message = models.TextField()
    leave_status = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    leave_days=models.IntegerField(default=0)
    objects = models.Manager()
    def __str__(self):
        return f'{self.staff_id.admin}'


